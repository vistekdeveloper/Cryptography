#------------------------------------------------------------------------------------------
# Client.py
#------------------------------------------------------------------------------------------
#!/usr/bin/env python3
# Please starts the tcp server first before running this client
 
import datetime
import hmac
import hashlib
import sys              # handle system error
import socket
import time

# (ANIQ) Imports needed for day-closing confidentiality + non repudiation
from Crypto.Cipher import AES               # AES-GCM used to check the day closing report is authentic
from Crypto.Random import get_random_bytes  # Fresh random nonce, needed for every encryption
from Crypto.PublicKey import RSA            # Load the client public key
from Crypto.Signature import pkcs1_15       # RSA Sig Scheme (non-repudiation)
from Crypto.Hash import SHA256              # hash used inside the RSA Sig check

global host, port

host = socket.gethostname()
port = 8888         # The port used by the server
cmd_GET_MENU = b"GET_MENU"
cmd_END_DAY = b"CLOSING"
menu_file = "menu.csv"
return_file = "day_end.csv"

SECRET_KEY = b"#B5Gh6eEwl$Me7" #HMAC
AES_GCM_KEY = b"0123456789abcdef0123456789abcdef"  # 32 bytes = AES-256 key

# (Aniq) load own private key to sign the day closing report
try:
    with open("keys/client_private.pem", "rb") as f:
        CLIENT_PRIVATE_KEY = RSA.import_key(f.read())
except FileNotFoundError:
    print("Missing keys/client_private.pem(run gen_keys.py from project root first)")
    sys.exit(1)


with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as my_socket:
    my_socket.connect((host, port))
    my_socket.sendall(cmd_GET_MENU )
    data = my_socket.recv(4096)
    #hints : need to apply a scheme to verify the integrity of data.  
    menu_data, menu_hmac = data.split(b"|") #split the received data into menu and hmac
    current_hmac = hmac.new(SECRET_KEY, menu_data, hashlib.sha256).hexdigest().encode() #generate hmac for received menu
    print("Current HMAC:", current_hmac.decode())
    print("Received HMAC:", menu_hmac.decode())

    if current_hmac == menu_hmac: #compare the hmacs
        print("HMAC verified successfully.")
    else:
        print("HMAC verification failed.")

    print("\n" + menu_data.decode() + "\n")

    menu_file = open(menu_file,"wb")
    menu_file.write(menu_data)
    menu_file.close()
    my_socket.close()

# print('Menu today received from server')
#print('Received', repr(data))  # for debugging use
my_socket.close()

with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as my_socket:
    my_socket.connect((host, port))
    #my_socket.sendall(cmd_END_DAY)
    try:
        out_file = open(return_file,"rb")
    except:
        print("file not found : " + return_file)
        sys.exit(0)
    

    
    #file_bytes = out_file.read(1024)
    ##while file_bytes != b'':
        # hints: need to protect the file_bytes in a way before sending out.
       #my_socket.send(file_bytes)
        #sent_bytes+=file_bytes
        #file_bytes = out_file.read(1024) # read next block from file
    #out_file.close()
    #my_socket.close()
#print('Sale of the day sent to server')

    # (Aniq) 
    plaintext = out_file.read() # read the whole file
    out_file.close() 

    nonce = get_random_bytes(12)    # Fresh nonce not reused
    cipher = AES.new(AES_GCM_KEY, AES.MODE_GCM, nonce=nonce) 
    ciphertext, tag = cipher.encrypt_and_digest(plaintext)  # encrypt and get the auth tag tgt

    signed_data = nonce + ciphertext + tag  # data that we are proving came from us
    hash_obj = SHA256.new(signed_data)
    signature =  pkcs1_15.new(CLIENT_PRIVATE_KEY).sign(hash_obj) # sign it with our private key

    my_socket.sendall(cmd_END_DAY) # header first
    my_socket.sendall(nonce)    # 12 bytes
    my_socket.sendall(signature) # 256 bytes
    my_socket.sendall(ciphertext) # variable length
    my_socket.sendall(tag)  # 16 bytes
    my_socket.close()

print('Sale of the day sent to server (encrypted + signed)')
#print('Sent', repr(sent_bytes))  # for debugging use
my_socket.close()
