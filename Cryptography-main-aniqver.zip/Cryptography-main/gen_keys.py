# (Aniq) RUN this file once from project root before server or client
# Generates the RSA key pair used to sign/verify

import os
from Crypto.PublicKey import RSA

os.makedirs("client/keys", exist_ok=True) # client keep private key here
os.makedirs("server/keys", exist_ok=True) # server public key

key = RSA.generate(2048) # 2048-bit RSA key pair for the client

with open("client/keys/client_private.pem", "wb") as f:
    f.write(key.export_key())

with open("server/keys/client_public.pem", "wb") as f:
    f.write(key.public_key().export_key())

print("Keys generated complete:")
print("- client/keys/client_private.pem ")
print("- server/keys/client_public.pem ")
