#------------------------------------------------------------------------------------------
# Server.py
#------------------------------------------------------------------------------------------
import hashlib
import hmac
from threading import Thread    # for handling task in separate jobs we need threading
import socket           # tcp protocol
import datetime         # for composing date/time stamp
import sys              # handle system error
import traceback        # for print_exc function
import time             # for delay purpose

# (ANIQ) Imports needed for day-closing confidentiality + non repudiation
from Crypto.Cipher import AES               # AES-GCM used to check the day closing report is authentic
from Crypto.PublicKey import RSA            # Load the client public key
from Crypto.Signature import pkcs1_15       # RSA Sig Scheme (non-repudiation)
from Crypto.Hash import SHA256              # hash used inside the RSA Sig check

global host, port

cmd_GET_MENU = "GET_MENU"
cmd_END_DAY = "CLOSING"
default_menu = "menu_today.txt"
default_save_base = "result-"

host = socket.gethostname() # get the hostname or ip address
port = 8888                 # The port used by the server



SECRET_KEY = b"#B5Gh6eEwl$Me7" #HMAC
AES_GCM_KEY = b"0123456789abcdef0123456789abcdef"  # 32 bytes = AES-256 key

# (ANIQ) sizes are fixed by the algo we chose
NONCE_SIZE = 12
SIG_SIZE = 256
TAG_SIZE = 16
# (ANIQ) Load Client public key so we can verify the sig they attach to every day-closing report.
try:
    with open("keys/client_public.pem", "rb") as f:
        CLIENT_PUBLIC_KEY = RSA.import_key(f.read())
except FileNotFoundError:
    print("Missing keys/client_public.pem(run gen_keys.py from project root first)")
    sys.exit(1)

def process_connection( conn , ip_addr, MAX_BUFFER_SIZE):  
    blk_count = 0
    net_bytes = conn.recv(MAX_BUFFER_SIZE)
    dest_file = open("temp","w")  # temp file is to satisfy the syntax rule. Can ignore the file.
    received_bytes = b'' #(Aniq) buffer for full closing message 

    is_closing = False #(Aniq) tracks if this connection is a CLOSING request


    while net_bytes != b'':
        if blk_count == 0: #  1st block
            #usr_cmd = net_bytes[0:15].decode("utf8").rstrip()
            #if cmd_GET_MENU in usr_cmd: # ask for menu
            # (Aniq) comparing raw BYTES instead of decoding first
            if net_bytes.startswith(cmd_GET_MENU.encode()):
                try:
                    src_file = open(default_menu,"rb")
                except:
                    print("file not found : " + default_menu)
                    sys.exit(0)
                while True:
                    read_bytes = src_file.read(MAX_BUFFER_SIZE)
                    if read_bytes == b'':
                        break
                    #hints: you may apply a scheme (hashing/encryption) to read_bytes before sending to client.
                    ##Hmac integrity check for the menu file sent to client, encryption not requried (Steven)
                    menu_hmac = hmac.new(SECRET_KEY, read_bytes, hashlib.sha256).hexdigest().encode() #generate hmac
                    conn.send(read_bytes + b"|" + menu_hmac) #send the menu bytes and hmac together to client
                    ##-------------------------------------------------------------------------------------
                src_file.close()
                print("Processed SENDING menu") 
                return
            #elif cmd_END_DAY in usr_cmd: # ask for to save end day order
                #Hints: the net_bytes after the cmd_END_DAY may be encrypted. 
                #now = datetime.datetime.now()
                #filename = default_save_base +  ip_addr + "-" + now.strftime("%Y-%m-%d_%H%M")                
                #dest_file = open(filename,"wb")

                # Hints: net_bytes may be an encrypted block of message.
                # e.g. plain_bytes = my_decrypt(net_bytes)
                #blk_count = blk_count + 1
            elif net_bytes.startswith(cmd_END_DAY.encode()): # ask for to save end day order
                # (ANIQ) Day closing AES-GCM confidentiality + RSA Sig non repudiation
                is_closing = True
                received_bytes += net_bytes[len(cmd_END_DAY):] # strip the closing header and keep the rest
                blk_count = blk_count + 1
        else:  # write subsequent blocks of END_DAY message block
            # Hints: net_bytes may be an encrypted block of message.
            net_bytes = conn.recv(MAX_BUFFER_SIZE)
            #dest_file.write(net_bytes)
            # last block / empty block
            received_bytes += net_bytes
    if is_closing:
        # (Aniq) parse the packet the client sent us:
        # nonce(12 bytes) + sig (256 bytes) + ciphertext (rest, minus last 16) + tag (16 bytes)
        nonce = received_bytes[:NONCE_SIZE]
        signature = received_bytes[NONCE_SIZE : NONCE_SIZE + SIG_SIZE]
        remainder = received_bytes[NONCE_SIZE + SIG_SIZE :]
        tag = remainder[-TAG_SIZE:]
        ciphertext = remainder[:-TAG_SIZE]
        signed_data = nonce + ciphertext + tag # must match exactly client signed

        try:
            # Does this sig really come from client over this data? Check if tampered
            hash_obj = SHA256.new(signed_data)
            pkcs1_15.new(CLIENT_PUBLIC_KEY).verify(hash_obj, signature)
            print("Signature verified - report is authentic and came from registered client")
            # Authenticity/integrity check via AES-GCM Bulit in tag. Raise error if detect alteration on ciphertext or tag in transit
            decipher = AES.new(AES_GCM_KEY, AES.MODE_GCM, nonce=nonce)
            decipher.decrypt_and_verify(ciphertext, tag) # confirming its genuine
            print("GCM authenticated passed - data not tampered with")
            # Confidentiality at rest: save nonce + ciphertext + tag as is stil fully encrypted instead of writing plaintext
            now = datetime.datetime.now()
            filename = default_save_base + ip_addr + "-" + now.strftime("%Y-%m-%d_%H%M")
            with open(filename, "wb") as f:
                f.write(nonce + ciphertext + tag)
            print("Saving file as " + filename + " (in AES-GCM state encrypted on disk")
            time.sleep(3)
            print("Processed Closing done")
        except (ValueError, TypeError, KeyError) as e:
            print("Signature or Authentication check failed: " + str(e))
    dest_file.close()
    return
            

    
    
    #dest_file.close()
    #print("saving file as " + filename)
    #time.sleep(3)
    #print("Processed CLOSING done") 
    #return

def client_thread(conn, ip, port, MAX_BUFFER_SIZE = 4096):
    process_connection( conn, ip, MAX_BUFFER_SIZE)
    conn.close()  # close connection
    print('Connection ' + ip + ':' + port + "ended")
    return

def start_server():
    global host, port
    # Here we made a socket instance and passed it two parameters. AF_INET and SOCK_STREAM. 
    soc = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    # this is for easy starting/killing the app
    soc.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    print('Socket created')
    
    try:
        soc.bind((host, port))
        print('Socket bind complete')
    except socket.error as msg:
        
        print('Bind failed. Error : ' + str(sys.exc_info()))
        print( msg.with_traceback() )
        sys.exit()

    #Start listening on socket and can accept 10 connection
    soc.listen(10)
    print('Socket now listening')

    # this will make an infinite loop needed for 
    # not reseting server for every client
    try:
        while True:
            conn, addr = soc.accept()
            # assign ip and port
            ip, port = str(addr[0]), str(addr[1])
            print('Accepting connection from ' + ip + ':' + port)
            try:
                Thread(target=client_thread, args=(conn, ip, port)).start()
            except:
                print("Terrible error!")
                traceback.print_exc()
    except:
        pass
    soc.close()
    return

start_server()  
